
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.util.Pair;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.*;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * icsd17222
 */
public class Client extends UnicastRemoteObject implements ChatListener{

    private static Interface stub;
    private static User ulogged = null; //metavlhth gia ton elegxo an o xrhsths exei sundethei orizontas to antikeimeno tou xrhsth
    private static Client client; //metavlhth h opoia voithaei sthn apothikeush twn egeggramenwn xrhstwn
    
    
    public Client() throws RemoteException{  //constructor ths klashs client
            super();
      }
    
    public void update(String msg) throws RemoteException{ //sunarthsh gia ulopoihsh callback
        System.out.println(msg);
       JFrame msgf=new JFrame("Discount");
       JTextArea msgarea=new JTextArea(msg);
       msgf.add(msgarea);
       msgf.pack();
       msgf.setVisible(true);
    }


    public static void main(String args[]) {

        try {
            client=new Client(); 
            Registry registry = LocateRegistry.getRegistry();
            //psaxnei to registry me to antistoixo onoma
            stub = (Interface) registry.lookup("//localhost/RMIServer");

            
        } catch (RemoteException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NotBoundException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
      
        Mainscreen();
    }

    public static void Mainscreen() { //grafika arxikhs othonhs
        JFrame f1 = new JFrame("App");
        f1.setDefaultCloseOperation(EXIT_ON_CLOSE);
        f1.setSize(600, 600);

        JPanel p2 = new JPanel();
        p2.setLayout(new FlowLayout());
        JButton logout = new JButton("Log out");
        logout.setBackground(Color.red);
        JPanel p1 = new JPanel();
        p1.setLayout((new BoxLayout(p1, BoxLayout.Y_AXIS)));
        JButton sub = new JButton("Sign up");
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton logb = new JButton("Login");
        logb.setAlignmentX(Component.CENTER_ALIGNMENT);
        JButton orderb = new JButton("Order/Payment for ticket");
        orderb.setAlignmentX(Component.CENTER_ALIGNMENT);
        JButton decb = new JButton("Decline Order");
        decb.setBackground(Color.red);
        JButton eventb = new JButton("Declare event");
        eventb.setAlignmentX(Component.CENTER_ALIGNMENT);
        JButton removeb = new JButton("Decline event");
        removeb.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton deluser = new JButton("Delete account");
        deluser.setBackground(Color.red);
        p2.add(logout);
        p2.add(deluser);
        p1.add(sub);
        p1.add(logb);
        p1.add(orderb);
        p2.add(decb);
        p1.add(eventb);
        p1.add(removeb);
        p1.setBackground(Color.DARK_GRAY);
        p2.setBackground(Color.DARK_GRAY);

        p1.add(p2);
        f1.add(p1);

        f1.pack();
        f1.setVisible(true);   //ylopoihsh koumpiwn arxikhs othonhs kai elegxos gia ektelesh tous
        sub.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (ulogged == null) {          //elegxos gia an o xrhsths einai hdh sundedemenos
                   
                    signupgui();
                } else {
                    JOptionPane.showMessageDialog(null, "You already logged in");
                }
            }
        });

        logb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (ulogged == null) {
                    logingui();
                } else {
                    JOptionPane.showMessageDialog(null, "You already logged in");
                }

            }
        });
        deluser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (ulogged != null) {
                        stub.deluser(ulogged);
                        JOptionPane.showMessageDialog(null,"account deleted");
                        ulogged=null;
                    } else {
                        JOptionPane.showMessageDialog(null, "You haven't logged in");
                    }
                } catch (RemoteException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        eventb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (ulogged != null && ulogged.isAdmin()) {
                    declareeventgui();
                } else if (ulogged.isAdmin()==false && ulogged!=null) {
                    JOptionPane.showMessageDialog(null, "You are not an admin");
                }
                else
                   JOptionPane.showMessageDialog(null, "You haven't logged in"); 

            }
        });
        removeb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (ulogged != null && ulogged.isAdmin()) {
                    removeeventgui();
                } else if (ulogged.isAdmin()==false && ulogged!=null) {
                    JOptionPane.showMessageDialog(null, "You are not an admin");
                }else
                    JOptionPane.showMessageDialog(null, "You haven't logged in");

            }
        });
        orderb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (ulogged != null) {
                    orderticketgui();
                }
                else
                    JOptionPane.showMessageDialog(null,"You havent logged in");
            }
        });
        decb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                decordergui();
            }
        });
        logout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               ulogged=null;
               JOptionPane.showMessageDialog(null,"You logged out");
            }
        });
    }

    public static void signupgui() {  //grafika gia sign up tou xrhsth
        JFrame f2 = new JFrame("Sign up");
        f2.setSize(300, 300);
        f2.setLayout(new BorderLayout());
        JPanel p3 = new JPanel();
        p3.setLayout(new GridLayout(7, 1));
        JLabel l1 = new JLabel("Surname-Vorname   ");
        JTextField svf = new JTextField();

        JLabel l2 = new JLabel("Phone Number   ");
        JTextField pnf = new JTextField();

        JLabel l3 = new JLabel("E-mail");
        JTextField emailf = new JTextField();

        JLabel l4 = new JLabel("Login-name");
        JTextField lnf = new JTextField();

        JLabel l5 = new JLabel("Password");
        JPasswordField pasf = new JPasswordField();

        JRadioButton urb = new JRadioButton("User");

        JRadioButton arb = new JRadioButton("Admin");

        JButton sub2 = new JButton("Sign up");
        
        JPanel p4 = new JPanel(new FlowLayout());

        JButton back = new JButton("Back");
        
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f2.setVisible(false);
            }
        });

        p4.add(urb);
        p4.add(arb);
        p3.add(l1);
        p3.add(svf);
        p3.add(l2);
        p3.add(pnf);
        p3.add(l3);
        p3.add(emailf);
        p3.add(l4);
        p3.add(lnf);
        p3.add(l5);
        p3.add(pasf);
        p3.add(p4);
        JPanel bp = new JPanel(new FlowLayout());
        bp.add(back);
        bp.add(sub2);
         
        f2.add(p3, BorderLayout.NORTH);
        f2.add(bp, BorderLayout.SOUTH);
        f2.setVisible(true);

        sub2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                User u;
                if (arb.isSelected()) { //elegxos gia epilogh twn radio button
                    u = new User(svf.getText(), pnf.getText(), emailf.getText(), lnf.getText(), pasf.getText(),true);
                } else {
                    u = new User(svf.getText(), pnf.getText(), emailf.getText(), lnf.getText(), pasf.getText(),false);
                }

                try {
                    stub.setuser(u); //ektelesh ths sunarthshs setuser tou interface h opoia dexetai to antikeimeno u kai to client 
                } catch (RemoteException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
                JOptionPane.showMessageDialog(null, "You ve been signed up");
                f2.setVisible(false);  //anoigma parathurou gia login
                logingui();
            }
        });
    }

    public static void logingui() { //ylopoihsh grafikwn gia login xrhsth
        JFrame f3 = new JFrame("Login");
        f3.setSize(300, 150);
        f3.setLayout(new BorderLayout());

        JPanel p5 = new JPanel();
        p5.setLayout(new GridLayout(3, 1));
        JLabel loginname = new JLabel("Login-name");

        JTextField lognamefld = new JTextField();

        JLabel loginpass = new JLabel("Password");
        JPasswordField passwordfld = new JPasswordField();

        JButton logb2 = new JButton("Login");
        JButton back2 = new JButton("Back");

        JPanel p6 = new JPanel(new FlowLayout());

        p5.add(loginname);
        p5.add(lognamefld);
        p5.add(loginpass);
        p5.add(passwordfld);
        p6.add(back2);
        p6.add(logb2);

        f3.getContentPane().add(p5, BorderLayout.NORTH);
        f3.getContentPane().add(p6, BorderLayout.SOUTH);
        f3.setVisible(true);

        back2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f3.setVisible(false);
            }
        });
        logb2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    Pair<User, String> pair = stub.checkuser(lognamefld.getText(), passwordfld.getText(),client); //ektelei synarthsh tou interface checkuser me to login name kai kwdiko p edwse o xrhsths k epistrefei ena zeygari to opoio periexei to antikeimeno u kathws kai ena mynhma string
                    ulogged = pair.getKey();
                    if (pair.getValue().equals("success")) {
                        JOptionPane.showMessageDialog(null, "You logged in sucessfully");
                        f3.setVisible(false);
                    }else if(pair.getValue().equals("wrongpassword"))
                        JOptionPane.showMessageDialog(null,"Wrong password");
                    else
                        JOptionPane.showMessageDialog(null,"You havent signed up");
                } catch (RemoteException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    public static void declareeventgui() { //ylopoihsh grafikwn gia dhlwsh theamatos(Event)
        JFrame f4 = new JFrame("Declare event");
        f4.setSize(300, 200);
        f4.setLayout(new BorderLayout());

        JLabel title = new JLabel("Title");
        JTextField titlefld = new JTextField();

        JLabel date = new JLabel("Date");
        UtilDateModel model = new UtilDateModel();
        Properties p = new Properties();
        p.put("text.today", "Today");
        p.put("text.month", "Month");
        p.put("text.year", "Year");
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
        JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());

        JLabel seats = new JLabel("Seats");
        SpinnerModel Model = new SpinnerNumberModel(1, 0, 1500, 1);
        JSpinner seatselect = new JSpinner(Model);

        JPanel btnpnel = new JPanel(new FlowLayout());
        JButton addevnt = new JButton("Add event");
        JButton end = new JButton("End");
        JButton back = new JButton("Back");

        btnpnel.add(back);
        btnpnel.add(addevnt);
        btnpnel.add(end);

        JPanel evntinfo = new JPanel(new GridLayout(4, 1));
        evntinfo.add(title);
        evntinfo.add(titlefld);
        evntinfo.add(date);
        evntinfo.add(datePicker);
        evntinfo.add(seats);
        evntinfo.add(seatselect);
        f4.add(new JLabel("Event's information"), BorderLayout.NORTH);
        f4.add(evntinfo, BorderLayout.CENTER);
        f4.add(btnpnel, BorderLayout.SOUTH);
        f4.setVisible(true);
        addevnt.addActionListener(new ActionListener() { //an pathsei add tote o xrhsths kateuthinetai se selida gia eisagwgh parastasewn tou theamatos
            @Override
            public void actionPerformed(ActionEvent e) {
                String date = datePicker.getJFormattedTextField().getText();
                int seats = (Integer) seatselect.getValue();
                Event evnt = new Event(titlefld.getText(), date, seats, new ArrayList<Show>()); //dhmiourgia antikeimenou evnt parastashs me ta stoixeia p edwse o xrhsths
                setshowsgui(evnt);
                f4.setVisible(false);
                JOptionPane.showMessageDialog(null,"Add shows");
            }
        });
        end.addActionListener(new ActionListener() { //an pathsei end tote kataxwrhte to theama xwris parastash...se periptwsh pou den exoun anakoinwthei akoma oi parastaseis
            @Override
            public void actionPerformed(ActionEvent e) {
                String date = datePicker.getJFormattedTextField().getText();
                int seats = (Integer) seatselect.getValue();
                Event evnt = new Event(titlefld.getText(), date, seats, new ArrayList<Show>());
                try {
                    System.out.println(stub.setevent(evnt));
                } catch (RemoteException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
                f4.setVisible(false);
            }
        });
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f4.setVisible(false);
            }
        });

    }

    public static void setshowsgui(Event evnt) { //ulopoihsh grafikwn gia eisagwgh parastasewn tou theamatos 
        JFrame f5 = new JFrame("Set event shows");
        f5.setSize(300, 200);
        f5.setLayout(new BorderLayout());

        JLabel shows = new JLabel("Add event's shows");
        JLabel showd = new JLabel("Show date");
        UtilDateModel model = new UtilDateModel();
//model.setDate(20,04,2014);
// Need this...
        Properties p = new Properties();
        p.put("text.today", "Today");
        p.put("text.month", "Month");
        p.put("text.year", "Year");
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
// Don't know about the formatter, but there it is...
        JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());

        JLabel showt = new JLabel("Show time");
        JSpinner timeSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm");
        timeSpinner.setEditor(timeEditor);
        timeSpinner.setValue(new Date());

        JLabel showc = new JLabel("Show ticket cost");
        SpinnerModel Model = new SpinnerNumberModel(5, 0, 100, 5);
        JSpinner ticketc = new JSpinner(Model);

        JButton nxt = new JButton("Add show");
        JButton end = new JButton("End");
        JButton back = new JButton("Back");
        JPanel btnpnl = new JPanel(new FlowLayout());
        btnpnl.add(back);
        btnpnl.add(nxt);
        btnpnl.add(end);

        JPanel showinfo = new JPanel(new GridLayout(4, 1));
        showinfo.add(showd);
        showinfo.add(datePicker);
        showinfo.add(showt);
        showinfo.add(timeSpinner);
        showinfo.add(showc);
        showinfo.add(ticketc);
        f5.add(shows, BorderLayout.NORTH);
        f5.add(showinfo, BorderLayout.CENTER);
        f5.add(btnpnl, BorderLayout.SOUTH);
        f5.setVisible(true);
        List<Show> showlist = new ArrayList<Show>();
        nxt.addActionListener(new ActionListener() { //an pathsei next dhladh na valei thn epomenh parastash 
            @Override
            public void actionPerformed(ActionEvent e) {
                String date = datePicker.getJFormattedTextField().getText();
                Object time = timeSpinner.getValue();
                String timestr = time.toString().substring(11, 16);
                int cost = (Integer) ticketc.getValue();
                Show s = new Show(date + " " + timestr, cost, new ArrayList<User>()); //dhmiourgia antikeimenou show me ta stoixeia tou xrhsth kai eisagwgh tou se lista
                showlist.add(s);
                datePicker.getJFormattedTextField().setText("");
                JOptionPane.showMessageDialog(null,"Show added");
            }
        });
        end.addActionListener(new ActionListener() { //an pathsei end
            @Override
            public void actionPerformed(ActionEvent e) {
                evnt.setShowl(showlist);  //eisagei thn lista me ta shows sto antikeimeno tou theamatos
                
                try {
                    JOptionPane.showMessageDialog(null,stub.setevent(evnt));  //ektelesh ths synarthshshs interface setevent
                } catch (RemoteException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
                f5.setVisible(false);
            }
        });
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f5.setVisible(false);
            }
        });

    }

    public static void removeeventgui() { //ylopoihsh grafikwn gia diagrafh enos theamatos analoga me ton titlo pou tha dwsei o xrhsths
        JFrame f6 = new JFrame("Remove an event");
        f6.setSize(200, 120);
        f6.setLayout(new BorderLayout());
        JLabel title = new JLabel("Add a title to remove");

        JTextField titlefld = new JTextField();

        JButton delete = new JButton("Delete");
        JButton back = new JButton("Back");

        JPanel btnpnl = new JPanel(new FlowLayout());
        btnpnl.add(back);
        btnpnl.add(delete);

        f6.add(title, BorderLayout.NORTH);
        f6.add(btnpnl, BorderLayout.SOUTH);
        f6.add(titlefld, BorderLayout.CENTER);
        f6.setVisible(true);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f6.setVisible(false);
            }
        });
        delete.addActionListener(new ActionListener() {  //me to pathma tou delete
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Event b = stub.removeevent(titlefld.getText());  //ektelei thn sunarthsh interface removeevent me ton titlo p edwse o xrhsths
                    if(b!=null)
                        JOptionPane.showMessageDialog(null,"Event:"+b.getTitle()+" deleted"); //an epistrepsei antikeimeno b diaforo tou null paei na pei oti diagrafthke
                    else
                        JOptionPane.showMessageDialog(null,"Event hasnt been found");   //diaforetika den vrethike to theama
                } catch (RemoteException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

    }

    public static void orderticketgui() { //yloppihsh grafikwn gia paraggelia eishthriwn..o xrhsths psaxnei gia theamata vash titlou h vash hmeromhnias(an vriskontai parastaseis theamatwn metaxu twn 2 hmeromhniwn from kai to p edwse o xrhsths)
            
        JFrame f7 = new JFrame("Order a ticket");
        f7.setSize(new Dimension(500,250));
        f7.setLayout(new BorderLayout());

        JLabel showf = new JLabel("From");
        JLabel showt = new JLabel("To");
        UtilDateModel model = new UtilDateModel();
        Properties p = new Properties();
        p.put("text.today", "Today");
        p.put("text.month", "Month");
        p.put("text.year", "Year");
        UtilDateModel model2 = new UtilDateModel();
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
        JDatePanelImpl datePanel2 = new JDatePanelImpl(model2, p);

        JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());
        JDatePickerImpl datePicker2 = new JDatePickerImpl(datePanel2, new DateLabelFormatter());

        JLabel ticktl = new JLabel("Search for event shows based on title");
        JLabel datel = new JLabel("Search shows based on dates");
        JTextField evntname = new JTextField();
        JPanel txtpnl = new JPanel(new GridLayout(4, 1));
        JPanel pnl = new JPanel(new FlowLayout());
        pnl.add(showf);
        pnl.add(datePicker);
        pnl.add(showt);
        pnl.add(datePicker2);

        txtpnl.add(ticktl);
        txtpnl.add(evntname);
        txtpnl.add(datel);
        txtpnl.add(pnl);

        JButton search = new JButton("Search");
        JButton back = new JButton("Back");
        JPanel btnpanel = new JPanel(new FlowLayout());
        btnpanel.add(back);
        btnpanel.add(search);

        f7.add(txtpnl, BorderLayout.NORTH);
        f7.add(btnpanel, BorderLayout.SOUTH);
        f7.setVisible(true);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                f7.setVisible(false);
            }
        });
        evntname.addKeyListener(new KeyListener() { //an arxisei kai plhktrologei mesa sto pedio eureshs vash titlou ,ta pedia hmeromhniwn exafanizonte
            @Override
            public void keyTyped(KeyEvent e) {
                datel.setVisible(false);
                pnl.setVisible(false);
                if (evntname.getText().equals("")) {  //xanaemfanizonte an to periexomeno tou pediou titlou einai keno
                    datel.setVisible(true);
                    pnl.setVisible(true);
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

        datePicker.addActionListener(new ActionListener() { //an pathsei panw sthn epilogh hmeromhnias sugkekrimena from exafanizonte ta pedia eisagwgh titlou
            @Override
            public void actionPerformed(ActionEvent e) {
                ticktl.setVisible(false);
                evntname.setVisible(false);
                if (datePicker.getJFormattedTextField().getText().equals("")) { //xanaemfanizonte an to datepicker einai keno
                    ticktl.setVisible(true);
                    evntname.setVisible(true);
                }
            }
        });

        search.addActionListener(new ActionListener() { //an pathsei search
            

            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Event> elist=null;
                if (evntname.isVisible()) {  //an to pedio anazhthsh vash titlou einai emfanes
                    try {
                        elist = stub.searchevent(evntname.getText()); //ektelei sunarthsh interface searchevent gia anazhthsh theamatos vash tou titlou p edwse k epistrefei mia lista me theamata
                    } catch (RemoteException ex) {
                        Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } else if (pnl.isVisible()) { //an to pedio anazhthshs vash hmeromhnias einai emfanhs
                    
                    try {
                        elist = stub.searchevent(datePicker.getJFormattedTextField().getText().concat(datePicker2.getJFormattedTextField().getText())); //enwnei tis 2 hmeromhnies twn 2 pediwn se ena string kai ektelei thn sunarthsh searchevent me auto
                    } catch (RemoteException ex) {
                        Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if(elist.isEmpty()){ //an h lista elist einai kenh tote ektypwnei antistoixo mynhma kai xanaanoigei thn selida orderticket
                    JOptionPane.showMessageDialog(null,"No events found");
                    orderticketgui();
                
                }else{
                f7.setVisible(false); //diaforetika kleinei thn selida kai trexeu thn sunarthshs fortwshs event
                loadeventsgui(elist);
                }
            }
        });
    }

    public static void loadeventsgui(ArrayList<Event> elist) { //ylopoihsh twn grafikwn kai topothetish twn koumpwn twn theamatwn vash ths listas theamatwn elist;
        JFrame f8 = new JFrame("Event selection");
        f8.setLayout(new BorderLayout());
        f8.setSize(400, 400);
        JButton[] evntbuts = new JButton[elist.size()];
        JPanel epane = loadeventbuts(evntbuts, elist);

        JLabel el = new JLabel("Events found:");
        f8.add(epane, BorderLayout.CENTER);
        f8.add(el, BorderLayout.NORTH);
        f8.setVisible(true);

        for (int i = 0; i < evntbuts.length; i++) {
            Event echoose = elist.get(i);
            evntbuts[i].addActionListener(new ActionListener() { //gia kathe koumpi theamatos
                @Override
                public void actionPerformed(ActionEvent e) { //an kapoios pathsei se auto tote kleinei h selida kai ekteleite h sunarthsh emfanishs parastasewn vash elist kai epiloghs theamatos echoose
                     f8.setVisible(false);
                     showlistgui(elist,echoose);
                }

            });

        }
    }

    public static JPanel loadeventbuts(JButton[] ebuttons, ArrayList<Event> elist) { //dhmiourgia koumpiwn me vash ta stoixeia tou elist kai topothetish tous se panel to opoio epistrefei
        JPanel epane = new JPanel();
        for (int i = 0; i < elist.size(); i++) {
          
            if (elist.get(i).getShowl().size() > 0) {
                ebuttons[i] = new JButton(elist.get(i).getTitle());
            } else {
                ebuttons[i] = new JButton(elist.get(i).getTitle() + "(No shows available for now)");
            }
            epane.add(ebuttons[i]);

        }
        return epane;
    }

   

    public static void showlistgui(ArrayList<Event> elist,Event echoose) //ylopoihsh grafikwn emfanishs parastasewn tou theamatos echoose
    {
        JFrame f9=new JFrame("Shows found for Event:"+echoose.getTitle());
        f9.setLayout(new BorderLayout());
        f9.setSize(300,300);
        ArrayList<Show> slist=null;
        for (int i = 0; i < elist.size(); i++) {
            
            if (elist.get(i).equals(echoose)) { //an h epilogh uparxei sthn lista 
                slist = (ArrayList<Show>) elist.get(i).getShowl(); //slist einai h lista me ta show tou event poy epelexe
            }

        }
        if(slist.isEmpty()) //an h lista parastasewn-show einai kenh
        {
            orderticketgui();
            JOptionPane.showMessageDialog(null,"No shows were found");
        }

        JButton[] showbuts = new JButton[slist.size()];

        JPanel spane = new JPanel();
        for (int i = 0; i < slist.size(); i++) { //dhmiourgia koumpiwn vash twn parastasewn ths listas
            showbuts[i] = new JButton("Show on  " + slist.get(i).getDatetime() + "   Price:" + slist.get(i).getCost()+" Available seats:"+(echoose.getSeats()-slist.get(i).getulist().size()));
            spane.add(showbuts[i]);

        }
        f9.add(spane,BorderLayout.CENTER);
        f9.add(new JLabel("Pick a show:"),BorderLayout.NORTH);
        f9.pack();
        f9.setVisible(true);
         for (int i = 0; i < showbuts.length; i++) {
             Show schoose=slist.get(i);
            showbuts[i].addActionListener(new ActionListener() { //gia kathe koumpi parastashs to opoio an paththei ekteleite h sunarthsh plhrwmhs(me epilogh event kai epilogh show) ws parametrous
                @Override
                public void actionPerformed(ActionEvent e) {
                   f9.setVisible(false);
                    paymentgui(echoose,schoose);
                }
            });
        }
        

    }

    public static void paymentgui(Event echoose,Show schoose) { //ylopoihsh grafikwn plhrwmhs me event kai show auta p epelexe o xrhsths
        JFrame f10=new JFrame("Payment");
        f10.setSize(300,300);
        f10.setLayout(new BorderLayout());
        JPanel p1=new JPanel(new GridLayout(6,1));
        JLabel cardname=new JLabel("Card full-name");
        JTextField namefld=new JTextField("");
        JLabel cardnum=new JLabel("Card number");
        JTextField numfld=new JTextField("");
        JLabel numofticket=new JLabel("Enter the number of seats you want to reserve");
        SpinnerModel Model = new SpinnerNumberModel(1, 0, 1500, 1);
        JSpinner numoftickts = new JSpinner(Model);
        JTextArea rtrnmsg=new JTextArea();
        p1.add(cardname);
        p1.add(namefld);
        p1.add(cardnum);
        p1.add(numfld);
        p1.add(numofticket);
        p1.add(numoftickts);
        JButton payb=new JButton("PAY");
        JButton calc=new JButton("CALC");
        JPanel p2=new JPanel(new FlowLayout());
        p2.add(calc);
        p2.add(payb);
        f10.add(p1,BorderLayout.NORTH);
              f10.add(rtrnmsg,BorderLayout.CENTER);
        f10.add(p2,BorderLayout.SOUTH);
        f10.setVisible(true);
        
        calc.addActionListener(new ActionListener() { //an pathsei to koumpi plhrwmhs
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    
                    int seats = (Integer) numoftickts.getValue();   
                    ArrayList<Show> schoosel=new ArrayList<Show>();
                    schoosel.add(schoose);
                    Event e1=new Event(echoose.getTitle(),echoose.getStart(),echoose.getSeats(),schoosel); //dhmiourgei antikeimeno event me ta stoixeia tou event p epelexe kai me to show p epelexe
                   
                    String msg=stub.reserveevent(e1,ulogged,seats);  //ektelesh sunarthshs interface me to antikeimeno to antikeimeno tou xrhsth kai ton arithmo krathsewn
                    rtrnmsg.setText(msg);
                } catch (RemoteException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        payb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(rtrnmsg.getText()!=""){
                JOptionPane.showMessageDialog(null,"You paid succesfully");
                f10.setVisible(false);
                }
                else
                    JOptionPane.showMessageDialog(null,"Please calculate first");
            }
        });
        
        System.out.println("aaaaaa");
    }
    public static void decordergui() // synarthsh me grafika gia diagrafh paraggelias eishthriwn vash onomatos
    {
        JFrame fdec=new JFrame("Decline an order");
        fdec.setSize(400,400);
        fdec.setLayout(new BorderLayout());
        JLabel titlel=new JLabel("Please enter event's name");
        JTextField titlefld=new JTextField("");
        JPanel p1=new JPanel(new GridLayout(2,1));
        p1.add(titlel);
        p1.add(titlefld);
        JButton delb=new JButton("Decline order");
        fdec.add(p1,BorderLayout.CENTER);
        fdec.add(delb,BorderLayout.SOUTH);
        fdec.setVisible(true);
        delb.addActionListener(new ActionListener() {  //o xrhsths otan pathsei decline order tote ekteleite h synarthsh declineorder tou interface
            @Override
            public void actionPerformed(ActionEvent e) {
                  try {
            if(stub.declineorder(titlefld.getText(), ulogged).equals("found"))
                    JOptionPane.showMessageDialog(null,"Event found and deleted");
            else
                JOptionPane.showMessageDialog(null,"No event with that name was found");
        } catch (RemoteException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
            }
        });
      
        
    }
}
