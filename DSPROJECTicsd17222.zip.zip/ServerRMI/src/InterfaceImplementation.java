
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.util.Pair;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author giann
 */
public class InterfaceImplementation implements Interface {

    private ArrayList<ChatListener> clients;//lista h opoia apothikeuei olous tous xrhstes poy exoun kanei login
    private ObjectOutputStream out;
    private ObjectInputStream in;

    protected InterfaceImplementation() {
        super();
        clients = new ArrayList<ChatListener>();
    }

    public void messageclient(String msg) throws RemoteException {
        for (ChatListener client : clients) {
            client.update(msg);
        }
    }
//sunarthsh signup ths efarmoghs h opoia dexetai antikeimeno user 

    public synchronized void setuser(User u) {
        
       
        ObjectOutputStream out;
        AppendableObjectOutputStream outa;
        File f = new File("Users.dat");
        try {

            if (f.createNewFile()) { //dhmiourgia kainourgiou arxeiou me xrhstes
                out = new ObjectOutputStream(new FileOutputStream(f));
                out.writeObject(u);   //pernaei to antikeimeno u me outputstream
                System.out.println("new one");
                out.flush();
                out.close();
            } else if (f.exists()) { //an uparxei hdh to arxeio tote kanei append to antikeimeno u sto arxeio
                outa = new AppendableObjectOutputStream(new FileOutputStream("Users.dat", true));
                System.out.println("already exists");
                outa.writeObject(u);
                outa.flush();
                outa.close();
            }

            System.out.println("user has been set");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
//login xrhsth to opoio pernei parametrous to name kai ton kwdiko p edwse o xrhsths kai epistrefei ena zeugari me u (successfull login tou xrhsth) kai antistoixo mynhma

    public synchronized Pair<User, String> checkuser(String name, String password,ChatListener client) {
        clients.add(client);//lista me eggegramenous xrhstes
        String state = null;//string to opoio gurnaei mesw pair mazi me to u
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("Users.dat"));
            boolean loop = true;
            while (loop) { //me thn xrhsh mias objectinputstream apo to arxeio users
                User u1 = (User) in.readObject();//diavazei kathe antikeimeno u p uparxei kai an vrethei antikeimeno loginname kai password idia me auta twn parametrwn ths sunarthshs
                if (u1.getLoginname().equals(name) && u1.getPassword().equals(password)) {
                    state = "success";//epituxia
                    System.out.println("yoooo");
                    loop = false; //termatizetai to loop kai epistrefei to zeugari me to antikeimeno p vrethike kai to string state
                    return new Pair(u1, state);
                } else if (password != u1.getPassword() && name.equals(u1.getLoginname())) {
                    state = "wrongpassword"; //se periptwsh p loginname einai to idio kai password diaforetiko epistrefei pair me null u kai string to parakatw state
                    loop = false;
                    return new Pair(null, state);
                }

              

            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
            state = "nosignup"; //an teleiwsei to loop tou arxeio kai den uparxoun alla antikeimena tote epistrefei state oti den vrethike o xrhsths kai to u einai null
        } catch (IOException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }

        return new Pair(null, "nosignup");
    }
//diagrafh xrhsth .dexetai parametro antikeimeno u (xrhsths o opoios hdh exei kanei login)

    public synchronized  void deluser(User u) throws RemoteException {
        
        ObjectInputStream in = null;
        ArrayList<User> list = new ArrayList();
        try { //pernaei ola ta atnikeimena xrhstwn se mia lista user list
            in = new ObjectInputStream(new FileInputStream("Users.dat"));
            while (true) {
                list.add((User) in.readObject());
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
//an teleiwsei to arxeio den kanei tipota
        } catch (IOException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                in.close(); //kleinei to inputstream
            } catch (IOException ex) {
                Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        for (int i = 0; i < list.size(); i++) { //an mesa sthn lista vrethei xrhsths idios me thn parametro
          
            if (u.toString().equals(list.get(i).toString())) {
                
                list.remove(i); //aferei to antikeimeno u p vrethike
            }
        }
        File f = new File("Users.dat");
        if (f.exists()) { //diagrafh arxeiou
            f.delete();
        }

        try {
            f.createNewFile(); //dhmiourgia neou arxeiou
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) { //perasma olwn twn antikeimenwn u ths listas sto arxeio users.dat
                out.writeObject(list.get(i));
                System.out.println(list.get(i));
                out.flush();
            }
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
//sunarthsh h opoia thetei ena event .dexete parametro ena event kai epistrefei ena string
    //ylopoihsh socket gia sundesh me 2o server   

    public synchronized String setevent(Event evnt) {
        String msg = null;
        
        try {
            Socket socket = new Socket("127.0.0.1", 5000); //sundesh me server kai output/inputstreams
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream  in = new ObjectInputStream(socket.getInputStream());
            out.writeInt(1); //grafei ena wste na katalavei o server ti tha kanei
            out.flush();
            out.writeObject(evnt);  // stelnei to antikeimeno event theamatos
            out.flush();
            msg = (String) in.readObject(); //dexete mynhma pou epistrefei o server
            out.close();
            in.close();

        } catch (IOException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;  //epistrefei to mynhma p esteile o server

    }
//synarthsh h opoia anazhta theama vash titlou h vash hmeromhniwn kai epistrefei lista

    public synchronized ArrayList<Event> searchevent(String title) {
        System.out.println("eventsearch");
        ArrayList<Event> elist = null;
        try {
           Socket socket = new Socket("127.0.0.1", 5000); //sundesh me server kai output/inputstreams
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream  in = new ObjectInputStream(socket.getInputStream());
            out.writeInt(2); //grafei 2 wste o server na katalavei oti prokeitai gia anazhthsh
            out.flush();
            out.writeObject(title); //stelnei to string tou titlou p edwse o xrhsths
            out.flush();
            elist = (ArrayList<Event>) in.readObject(); //epistrofh listas apo ton socket server
            out.close();
            in.close();
            System.out.println("whattt");

        } catch (IOException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return elist;
    }

    //sunarthsh gia diagrafh theamatos vash titlou kai epistrefei ena antikeimeno theamatos
    public synchronized Event removeevent(String title) {
        System.out.println("removeevent");
        Event e = null;
        try {
           Socket socket = new Socket("127.0.0.1", 5000); //sundesh me server kai output/inputstreams
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream  in = new ObjectInputStream(socket.getInputStream());
          
            out.writeInt(3); //grafei 3 wste o socket server na katalavei oti prokeitai gia diagrafh theamatos
            out.flush();
            out.writeObject(title); //stelnei ton titlo p edwse o xrhsths ston socket server
            out.flush();
           
            e = (Event) in.readObject();  //pernei antikeimeno apo socket server kai to epistrefei
             out.close();
            in.close();
        } catch (IOException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return e;

    }
    //sunarthsh gia krathsh thesewn dexete event to opoio exoume ftiaxei katallhla.xrhsth u kai arithmo thesewn p thelei na kleisei o xrhsths

    public synchronized String reserveevent(Event echoose, User u, int seats) {
        String rtrnmsg=null;
        try {
            Socket socket = new Socket("127.0.0.1", 5000); //sundesh me server kai output/inputstreams
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream  in = new ObjectInputStream(socket.getInputStream());
            
            out.writeInt(4);//grafei 4 wste o socket server na katalavei oti prokeitai gia thn diadikasia ths krathsh
            out.flush();
            out.writeObject(u); //stelnei to antikeimeno u tou xrhsth poy prokeitai na kanei krathsh
            out.flush();
            out.writeObject(echoose); //stelnei to epilegmeno antikeimeno typou event
            out.flush();
            out.writeInt(seats);  //stelnei twn arithmo thesewn p thelei nakleisei
            out.flush();

            String msg = (String) in.readObject(); //pernei mynhma apo socket server
            if (msg.equals("discount")) {
                System.out.println(msg);
                Event e=(Event)in.readObject();
                Show s=(Show) in.readObject();
                messageclient("You have a 40% discount for:"+e.getTitle()+" on "+s.getDatetime());
                 rtrnmsg=(String) in.readObject();
            } else {
                
                rtrnmsg=(String) in.readObject();
            }
             out.close();
            in.close();
        } catch (IOException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rtrnmsg;
    }//sunarthsh gia akyrwsh paraggelias eishthriwn vash titlou p edwse o xrhsths 

    public synchronized String declineorder(String title, User u) {
        try {
            Socket socket = new Socket("127.0.0.1", 5000); //sundesh me server kai output/inputstreams
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream  in = new ObjectInputStream(socket.getInputStream());
        
            out.writeInt(5); //grafeu 5 wste o server na katalavei gia to poia diadikasia prokeitai 
            out.flush();
            out.writeObject(title); //grafei ton titlo event p edwse o xrhsths
            out.flush();
            out.writeObject(u); //grafei to antikeimeno u tou xrhsth
            out.flush();
            if(in.readObject().equals("found"))
                return "found";
            
             out.close();
            in.close();
           
        } catch (IOException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InterfaceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "notfound";
    }

    

}
