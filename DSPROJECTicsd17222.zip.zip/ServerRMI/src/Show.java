
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;




/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author giann
 */
public class Show implements Serializable{
    private String datetime;
    private double cost;
    private List<User> ulist;

    public Show(String datetime,double cost, List<User> ulist) {
        this.datetime = datetime;
        this.cost = cost;
        this.ulist = ulist;
    }

   

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public List<User> getulist() {
        return ulist;
    }

    public void setulist(List<User> ulist) {
        this.ulist = ulist;
    }

    @Override
    public String toString() {
        return "Show{" + "datetime=" + datetime + ", cost=" + cost + ", array=" + ulist + '}';
    }
}