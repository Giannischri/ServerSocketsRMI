
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import javafx.util.Pair;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author giann
 */
public interface Interface extends Remote {
    void setuser(User u) throws RemoteException; 
     Pair<User, String> checkuser(String name,String password,ChatListener client) throws RemoteException;
     void deluser(User u) throws RemoteException;
     String setevent(Event evnt) throws RemoteException;
     
     ArrayList<Event> searchevent(String title) throws RemoteException;
     Event removeevent(String title) throws RemoteException;
    String reserveevent(Event echoose,User u,int seats) throws RemoteException;
    String declineorder(String title,User u) throws RemoteException;
   
}
