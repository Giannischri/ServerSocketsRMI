import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.registry.Registry; 
import java.rmi.registry.LocateRegistry; 
import java.rmi.RemoteException; 
import java.rmi.server.UnicastRemoteObject; 
import java.util.ArrayList;
import javafx.util.Pair;
// author:icsd17222
public class Server extends InterfaceImplementation { 
   public Server() throws RemoteException {
   super();
   } 
   public static void main(String args[]) { 
      try { 
       
         Interface obj = new InterfaceImplementation(); 
    
         //kanei export to object
         Interface stub = (Interface) UnicastRemoteObject.exportObject((Interface)obj, 0);  
         
         //  dhmiourgei to object sto registry
         Registry registry = LocateRegistry.createRegistry(1099); 
         
         registry.bind("//localhost/RMIServer", stub);  
      
         
         System.err.println("Server ready"); 
      } catch (Exception e) { 
         System.err.println("Server exception: " + e.toString()); 
         e.printStackTrace(); 
      } 
   } 

   
} 
