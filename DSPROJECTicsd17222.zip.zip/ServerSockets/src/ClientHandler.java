
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.text.Collator;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author giann
 */
public class ClientHandler implements Runnable {

    private static Socket client;
    private static ObjectInputStream in, inputFromClient;
    private static ObjectOutputStream out, outputToClient;
    private static boolean slock=false;
    

    public ClientHandler(Socket client) throws IOException {
        this.client = client;
        inputFromClient = new ObjectInputStream(client.getInputStream());
        outputToClient = new ObjectOutputStream(client.getOutputStream());
    }

    @Override
    public void run() {
        try {
           
            System.out.println("o server diavazei integer"); //analoga me to ti stelnei o rmi server pratei analogos
          synchronized(this){
              notifyAll();
            switch (inputFromClient.readInt()) {
              
                case 1: {
                   
                    setevent();
                    
                    break;
                }
                case 2: {
                 
                    while(slock==true) //katallhla locks kai notify gia race condition px exei gemisei to event k o xrhsths paragelnei eishthria
                       wait();            //giauto thelei lock gia na ginei swsta h makeorder
                        checkfile();
                    showevents();
                    slock=true;
                 
                    break;
                }

                case 3: {
                    removeevent();
                    
                    break;
                }
                case 4: {
                   
                    while(slock==false)
                        wait();
                    makeanorder();
                    slock=false;
                   
                    break;
                }
                case 5: {
                    declineorder();
                   
                    break;
                }
            }
           }
           
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
//didikasia gia dhlwsh event

    private synchronized void setevent() throws InterruptedException {
        try {
            Event e = (Event) inputFromClient.readObject(); //pernei to antikeimeno e apo ton rmi server
            
            if (new File("Events.dat").createNewFile()) { //an ti arxeio events den yparxei to dhmiourgei kai pernaei me outputstream to antikeimeno sto arxeio
                out = new ObjectOutputStream(new FileOutputStream("Events.dat"));
                out.writeObject(e);
                out.flush();
                out.close();
            } else if (new File("Events.dat").exists()) { //an to arxeio events uparxei tote kanei apend to antikeimeno e sto arxeio events
                out = new AppendableObjectOutputStream(new FileOutputStream("Events.dat", true));
                out.writeObject(e);
                out.flush();
                out.close();
            }
            outputToClient.writeObject("success"); //stelneiu ston rmi server mynhma success gia epituxia
            //System.out.println("sucess");
    
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
    }
//sunarthsh diagrafhs event apo arxeio

    private synchronized void removeevent() throws IOException, InterruptedException {
        
     
        ArrayList<Event> evntlist = new ArrayList<Event>(); //dhmiourgia listas tupou event
        Event ereturn = null;    //arxikopoihsh event to opoio tha gurisei ston rmi gia epivaivewsh (auto p diagrafete)
        
        try {
            String title = (String) inputFromClient.readObject(); //pernei ton titlo tou event apo ton rmi server
            if (new File("Events.dat").exists()) { //an to arxeio events uparxei t
                in = new ObjectInputStream(new FileInputStream("Events.dat"));

                while (true) {
                    Event e = (Event) in.readObject(); //vazei sthn lista kathe event pou diavazei apo to arxeio events
                    evntlist.add(e);
                    
                    if (e.getTitle().equals(title)) { //an vrethei event me idio titlo me auton p edwse o xrhsths to diagrafei apo thn lista kai tha to epistrepsei
                        evntlist.remove(e);
                        ereturn = e;
                    }
                }
            }
        } catch (EOFException ex) {
            in.close();
            newfile(evntlist); //djmiopurgia neou arxeiou me thn lista p eftiaxe
        } catch (ClassNotFoundException | IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        outputToClient.writeObject(ereturn); //epistrofh antikeimenou to opoio diagrafthke ston rmi server
    
      
    }
//sunarthsh ulopoihshs gia thn dhmiourgia neou arxeio events apo mia lista

    private static void newfile(ArrayList<Event> list)  {
       
        try {
            
            File f = new File("Events.dat");
            f.delete(); //diagrafh tou arxeiou events kai dhmiourgia kainourgiou
            f.createNewFile();
            out = new ObjectOutputStream(new FileOutputStream(f));
            for (int i = 0; i < list.size(); i++) { //pernaei kathe stoixeio ths listas sto arxeio me ena outputstream
                out.writeObject(list.get(i));
                System.out.println(list.get(i).toString());
                out.flush();
            }
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
//sunarthsh emfanishs theamatwn

    private synchronized void showevents() throws IOException, InterruptedException {
 
        LocalDateTime localDateTime = LocalDateTime.now();

        Date datenow = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());//wra twra
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);//format gia metatroph string se date

        ArrayList<Event> elist = new ArrayList<Event>();
        try {
            
            String title = (String) inputFromClient.readObject();//pernei to string apo ton client(eite titlos eite hmeromhnies se ena string)
            
            String pattern = "[0-9]{4}(-[0-9]{2}){2}";

            Pattern r = Pattern.compile(pattern);
            Matcher m = r.matcher(title);
            in = new ObjectInputStream(new FileInputStream("Events.dat"));
            if (m.find()) { //an to string periexei to parapanw patern dhladh na einai hmeromhnia tote

                
                String strdatefrom = title.substring(0, 10);//kobei to string kai pernei to date from kai date to(apo-mexri)
               
                Date datefrom = format.parse(strdatefrom); //metatroph apo string se date
                String strdateto = title.substring(10, 20);
                Date dateto = format.parse(strdateto);
                while (true) {//diavazei kathe antikeimeno toy arxeiu events
                    Event e = (Event) in.readObject();
                    if (e.getStart().equals("")) { //an h hmeromhnia einai kenh tote epistrefei
                        return;
                    }
                    Date dateevnt = format.parse(e.getStart());
                    // if (dateevnt.compareTo(dateto) >= 0 ) {
                    //return;
                    // }
                    ArrayList<Show> slist = (ArrayList<Show>) e.getShowl(); //slist einai h lista show tou kathe event
                    ArrayList<Show> slist2 = new ArrayList<Show>();//kainourgia lista shows
                    for (int i = 0; i < slist.size(); i++) { //elegxei kathe show tou event(slist)an einai metaxu tou date from kai tou date to
                        if (format.parse(slist.get(i).getDatetime().substring(0, 10)).compareTo(datefrom) >= 0 && format.parse(slist.get(i).getDatetime().substring(0, 10)).compareTo(dateto) <= 0) {
                            slist2.add(slist.get(i));//to vazei sthn kainourgia lista
                            System.out.println("xaxaaa");
                        }
                    }
                    e.setShowl(slist2);//thetei thn lista sto event
                    elist.add(e);//vazei to event se mia lista

                }
            } else { //an to string einai title

                while (true) { //diavazei kathe antikeimeno event kai an vrei ena me idio titlo m auto p edwse o xrhsths to vazei  sthn lista
                    Event e = (Event) in.readObject();
                    if (e.getTitle().equals(title)) {
                        elist.add(e);
                       
                    }

                }
            }
        } catch (EOFException ex) {
            
            outputToClient.writeObject(elist); //stelnei thn lista ston rmi client kai meta autos to stelnei sto client
            
        } catch (ParseException | IOException | ClassNotFoundException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
//sunarthsh diagrafhs double h opoia kanei sort ths listas alfabhtika kai diagrafei diplotypa

    public static void checkfordouble(ArrayList<Event> elist) {

        Collections.sort(elist, new Comparator<Event>() {
            @Override
            public int compare(final Event lhs, Event rhs) {
                return lhs.getTitle().compareToIgnoreCase(rhs.getTitle());
            }
        });
        for (int i = 0; i < elist.size() - 1; i++) {
            if (elist.get(i).getTitle().equals(elist.get(i + 1).getTitle())) {
                elist.remove(i);
            }
        }

    }
//sunarthsh h opoia ulopoiei thn paraggelia tou xrhsth

    public synchronized void makeanorder() throws IOException, InterruptedException {
        
        Event e1 = null; //antikeimeno e1
        ArrayList<Event> elist = new ArrayList<Event>();
        try {
            //pernei to antikeimeno xrhsth apo ton rmi server kathws kai to event p epelexe
            User u = (User) inputFromClient.readObject();
            Event echoose = (Event) inputFromClient.readObject();

            in = new ObjectInputStream(new FileInputStream("Events.dat"));
            while (true) {//elegxei ta stoixeia tou arxeiou events
                Event e = (Event) in.readObject();
                elist.add(e);//vazei kathe antikeimeno theamatos sthn lista
                if (echoose.getTitle().equals(e.getTitle())) { //an vrethei antikeimeno me idio titlo me auto p epelxe o xrhsths
                    ArrayList<Show> slist = (ArrayList<Show>) e.getShowl();//pernei thn lista tou antikeimenou
                  
                    for (int z = 0; z < echoose.getShowl().size(); z++) { //elegxei kathe show p exei epilexei o xrhsths dhladh 1
                        for (int i = 0; i < slist.size(); i++) { //elegxei kathe stoixeio ths listas slist tou antikeimenou e
                            
                            double d = 1;  //metavlhth gia discount ama uparxei

                            if (slist.get(i).toString().equals(echoose.getShowl().get(z).toString())) { //an vrethei show to opoio einai idio me auto p epelexe o xrhsths
                               
                                if (e.getSeats() - e.getShowl().get(i).getulist().size() <= 10) //an apomenoun ligotero apo 10 theseis sto show tou xrhsth d=0.4 gia ekptwsh
                                {
                                    d = 0.4;
                                }
                                ArrayList<User> ulist = (ArrayList<User>) e.getShowl().get(i).getulist();//pernei thn lista me tous xrhstes ths parastashs show
                                int seats = inputFromClient.readInt(); //diavazei tis theseis p edwse o xrhsths
                                if (ulist.size() + seats <= e.getSeats()) { //an uparxoun perisies theseis
                                    for (int k = 0; k < seats; k++) { //tote vazei ton xrhsth sthn lista u toses fores oses einai kai oi krathseis
                                        ulist.add(u);
                                    }
                                    
                                    e.getShowl().get(i).setulist(ulist);//vazei thn lista xrhstwn sto antikeimeno
                                    e1 = e;
                                    elist.remove(e);//diagrafei to antikeimeno e apo thn lista kai grafei ston rmi server to parakatw mynhma plhrwmhs

                                    if (checkfordiscount(e, e.getShowl().get(i)) == true) {//an h sunarthsh checkfordiscount einai true tote vazei thn ekptwsh 40% sthn timh ths parastashs

                                        outputToClient.writeObject("discount");
                                              //stelnei mynhma oti tha uparxei ekptwsh gia rmi call back kathws kai event kai show xrhsth
                                        outputToClient.writeObject(e);
                                        outputToClient.writeObject(e.getShowl().get(i));

                                    } else {
                                        outputToClient.writeObject("No discount");
                                    }
                                          //stelnei mynhma to opoio periexei plhrofories
                                    outputToClient.writeObject("Pay:" + (seats * d * e.getShowl().get(i).getCost()) + " for event:" + e.getTitle() + " on:" + e.getShowl().get(i).getDatetime());
                                    elist.add(e1);//vazei sthn lista to neo antikeimeno e1
                                   
                                } else { ///se periptwsh p den uparxoun diathesimes theseis stelnei to parakatw mynhma
                                    outputToClient.writeObject("Not so many available seats.Available: " + (e.getSeats() - ulist.size()));
                                }
                            }
                        }
                    }
                }
            }
        } catch (EOFException ex) {
            newfile(elist); //dhmiourgia neou arxeiou apo thn lista events elist
        } catch (ClassNotFoundException | IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
   
       
        
        
    }
//arxeio elegxou gia egkura shows

    public  void checkfile() throws InterruptedException {
        
        
        LocalDateTime localDateTime = LocalDateTime.now();
        Date datenow = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        ArrayList<Event> elist = new ArrayList<Event>();
        try {
            in = new ObjectInputStream(new FileInputStream("Events.dat"));
            while (true) { //diavazei kathe antikeimeno e apo to arxeio
                Event e = (Event) in.readObject();
                e = checkshows(e, datenow); //ektelei thn checkshows gia kathe e kai epistrefei e
                if (e.getShowl().size() > 0) { //an to antikeimeno e exei shows tote to vazei se lista
                    elist.add(e);
                }
                //elist.add(e);

            }
        } catch (EOFException ex) {
            checkfordouble(elist);//elegxei gia diplotupta
            newfile(elist);//dhmiourgia neou arxeiou apo thn lista
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException | ClassNotFoundException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
       

    }
//sunarthsh h opoia elegxei tis parastashs tou theamatos an einai egkures(swstwn hmeromhniwn.Dexetai twrinh mera kai antikeimeno event kai to epistrefei tropoohmeno

    private static Event checkshows(Event e, Date date1) throws ParseException {

        ArrayList<Show> newslist = new ArrayList<Show>();
        ArrayList<Show> oldslist = (ArrayList<Show>) e.getShowl();
        for (int i = 0; i < oldslist.size(); i++) { //gia kathe stoixeio ths oldlist dhladh ths listas parastasewn
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
            Date date = format.parse(oldslist.get(i).getDatetime().substring(0, 10)); //metatroph hmeromhnias parastashs se date
            if (date1.compareTo(date) <= 0 && e.getSeats() > oldslist.get(i).getulist().size()) { //elegxei an h hmeromhnia ths parastashs den einai xeperasmenh kai an den exoun kleisei oles oi theseis
                newslist.add(oldslist.get(i));//vazei to show sthn nea lista
             
            }
        }
        e.setShowl(newslist); //thetei thn lista me parastaseis sumfwna me thn kainourgia lista
        return e;  //epistrefei to tropopoihmeno antikeimeno e
    }
//sunarthsh ulopoihshs ths akurwshs paragelias

    public synchronized void declineorder() throws IOException, InterruptedException {
        
        String state = "notfound";
        LocalDateTime localDateTime = LocalDateTime.now();
        Date datenow = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        ArrayList<Event> elist = new ArrayList<Event>();
        try {
//pernei ton titlo apo to rmi server kathws kai ton xrhsth u
            String title = (String) inputFromClient.readObject();
            User u = (User) inputFromClient.readObject();
            in = new ObjectInputStream(new FileInputStream("Events.dat"));
           
            while (true) { //gia kathe stoixeio e tou arxeiou events
                Event e = (Event) in.readObject();
                if (e.getTitle().equals(title)) { //an vrethei antikeimeno me idio titlo m auton p edwse o xrhsths
                    for (int i = 0; i < e.getShowl().size(); i++) { //gia kathe parastash p exei to event
                        
                        ArrayList<User> ulist = new ArrayList<User>();//kainourgia lista xrhstwn kai dateev einai h hmeromhnia tou kathe show
                        Date dateev = format.parse(e.getShowl().get(i).getDatetime().substring(0, 10));
                        for (int j = 0; j < e.getShowl().get(i).getulist().size(); j++) { //elegxei thn lista xrhstwn tou show
                            //an o xrhsths u uparxei mesa sthn lista xrhstwn tou show kai to show den einai shmera epistrefei
                            if (e.getShowl().get(i).getulist().get(j).toString().equals(u.toString()) && datenow.compareTo(dateev) < 0) {
                                break;

                            } else { //diaforetika vazei to kathe xrhsth se mia kainourgia lista

                                ulist.add(e.getShowl().get(i).getulist().get(j));
                            }
                        }
                        //thetei thn lista tou show ws h kainourgia lista ulist
                        e.getShowl().get(i).setulist(ulist);
                    }
                    state = "found";//gia na mynhma oti uparxei ontws o titlos p anazhthse 
                }
                //vazei to allagmeno antikeimeno e se mia lista
                elist.add(e);

            }
        } catch (EOFException ex) {
            for (int i = 0; i < elist.size(); i++) {
                System.out.println(elist.get(i));
            }
            outputToClient.writeObject(state); //stelnei ston rmi server mynhma katastashs
            newfile(elist); //dhmiourgia neou arxeiou vash listas
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    //sunarthsh elegxou gia ekptwsh kai ulopoihsh callbacks

    public static boolean checkfordiscount(Event e, Show s) {
        LocalDateTime localDateTime = LocalDateTime.now();
        Date datenow = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
        //an h mera p egine h plhrwmh theamatos den einai sk dhladh den xekinaei me s (saturday/sunday)kai apomenoun ligotero apo 10 diathesimes theseis tote epistrefei true,alliws epistrefei false
        if (datenow.toString().startsWith("S") == false && e.getSeats() - s.getulist().size() < 10) {
            
            return true;
        }
        return false;
    }

}
