
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * icsd17222
 */
public class Server2 {

private static ExecutorService pool=Executors.newFixedThreadPool(20);
    public static void main(String[] args) throws IOException {

        ServerSocket server = new ServerSocket(5000);
        while (true) {
            System.out.println("Server started");
            System.out.println("Waiting for a client ...");
            Socket socket = server.accept();
            System.out.println("Client accepted");
            ClientHandler thread = new ClientHandler(socket);
            pool.execute(thread);
            
        }

    }
}
