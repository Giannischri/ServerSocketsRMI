
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author giann
 */
public class Event implements Serializable {
    private String title;
    private String   start;
    private int   seats;
    private List<Show> showl;

    public Event(String title,String start, int seats, List<Show> showl) {
        this.title = title;
        this.start = start;
        this.seats = seats;
        this.showl = showl;
    }
    

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public List<Show> getShowl() {
        return showl;
    }

    public void setShowl(List<Show> showl) {
        this.showl = showl;
    }

    @Override
    public String toString() {
        return "Event{" + "title=" + title + ", start=" + start + ", seats=" + seats + ", showl=" + showl + '}';
    }
    
    
    
}
