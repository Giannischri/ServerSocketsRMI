
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author giann
 */
public class User implements Serializable {
    public String fullname;
    public String phone;
    public String email;
    public String loginname;
    public String password;
    public boolean admin;

    public User(String fullname, String phone, String email, String loginname, String password, boolean admin) {
        this.fullname = fullname;
        this.phone = phone;
        this.email = email;
        this.loginname = loginname;
        this.password = password;
        this.admin = admin;
    }

  

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    @Override
    public String toString() {
        return "User{" + "fullname=" + fullname + ", phone=" + phone + ", email=" + email + ", loginname=" + loginname + ", password=" + password + ", admin=" + admin + '}';
    }
    
    
}
